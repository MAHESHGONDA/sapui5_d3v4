sap.ui.define(['sap/ui/core/mvc/Controller',
	'sap/ui/model/json/JSONModel'
], function(Controller, JSONModel) {
	'use strict';
	return Controller.extend('com.d3.demo.controller.Overview', {

		onInit: function() {
			var oModel = new sap.ui.model.json.JSONModel(jQuery.sap.getModulePath("com.d3.demo.model", "/data.json"));
			this.getView().setModel(oModel);
		}

	});
});